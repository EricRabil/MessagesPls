make package
make install
ssh -t mainphone "killall -9 Cydia"
ssh -t mainphone "open com.saurik.Cydia"